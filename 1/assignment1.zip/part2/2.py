import one
import two
one.main()
two.main()