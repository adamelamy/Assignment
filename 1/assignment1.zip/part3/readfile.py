filename = open("file2","r")
content = filename.readline()
print(len(content))